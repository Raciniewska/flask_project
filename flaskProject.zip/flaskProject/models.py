from typing import List
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
class Class_variables(db.Model):
    __tablename__ = 'class_variables'
    id_class_variables = db.Column(db.Integer, primary_key=True, autoincrement=True)
    liczba_zlozonych_zamowien = db.Column(db.Integer)
    def __repr__(self) -> str:
        return (
            '<Class_variables('
            f'id={self.id_class_variables}, '
            f'liczba_zlozonych_zamowien={self.liczba_zlozonych_zamowien}, '
            ')>'
        )

class Dostawca(db.Model):
    __tablename__ = 'dostawca'
    id_osoby = db.Column(db.Integer, primary_key=True, autoincrement=True)
    imie=db.Column(db.String)
    nazwisko=db.Column(db.String)
    adres=db.Column(db.String)
    adres_email=db.Column(db.String)
    data_zatrudnienia=db.Column(db.Date)
    godziny_pracy=db.Column(db.String)
    haslo=db.Column(db.String)
    liczba_godzin_przepracowaanych_w_msc=db.Column(db.Integer)
    login=db.Column(db.String)
    numer_telefonu=db.Column(db.String)
    rodzaj_umowy=db.Column(db.String)
    stawka_godzinowa=db.Column(db.NUMERIC(5,2))
    firma=db.Column(db.String)
    typ_samochodu=db.Column(db.String)

    @classmethod
    def get_dostawcy(cls) -> List['Dostawca']:

        dostawcy = db.session.query(
            Dostawca.id_osoby,
            Dostawca.nazwisko,
            Dostawca.imie,
            Dostawca.adres_email,
            Dostawca.firma,
            Dostawca.numer_telefonu,
            Dostawca.godziny_pracy)
        return dostawcy

    @classmethod
    def get_firmy(cls) -> List['Dostawca']:
        dostawcy = db.session.query(
            Dostawca.firma)
        return dostawcy

    def __repr__(self) -> str:
        return (
            '<Dostawca('
            f'imie={self.imie}, '
            f'nazwisko={self.nazwisko}, '
            f'adres mailowy={self.adres_email}, '
            f'telefon={self.numer_telefonu}, '
            f'godziny pracy={self.godziny_pracy}'
            ')>'
        )

class Pracownik_biura(db.Model):
    __tablename__ = 'pracownik_biura'

    id_osoby = db.Column(db.Integer, primary_key=True, autoincrement=True)
    imie=db.Column(db.String)
    nazwisko=db.Column(db.String)
    adres=db.Column(db.String)
    adres_email=db.Column(db.String)
    data_zatrudnienia=db.Column(db.Date)
    godziny_pracy=db.Column(db.String)
    haslo=db.Column(db.String)
    liczba_godzin_przepracowaanych_w_msc=db.Column(db.Integer)
    login=db.Column(db.String)
    numer_telefonu=db.Column(db.String)
    rodzaj_umowy=db.Column(db.String)
    stawka_godzinowa=db.Column(db.NUMERIC(5,2))
    pesel=db.Column(db.String)
    liczba_wykorzystanych_dni_urlopu=db.Column(db.Integer)
    numer_pokoju=db.Column(db.Integer)
    posiadany_sprzet_elektroniczny=db.Column(db.String)

    @classmethod
    def get_pracownicy(cls) -> List['Pracownik_biura']:

        pracownicy_biura = db.session.query(
            Pracownik_biura.id_osoby,
            Pracownik_biura.imie,
            Pracownik_biura.nazwisko,
            Pracownik_biura.adres_email,
            Pracownik_biura.numer_telefonu,
            Pracownik_biura.godziny_pracy)
        return pracownicy_biura

    def __repr__(self) -> str:
        return (
            '<Pracownik Biura('
            f'imie={self.imie}, '
            f'nazwisko={self.nazwisko}, '
            f'adres mailowy={self.adres_email}, '
            f'telefon={self.numer_telefonu}, '
            f'godziny pracy={self.godziny_pracy}'
            ')>'
        )

class Produkt(db.Model):
    __tablename__ = 'produkt'

    id_produktu = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nazwa=db.Column(db.String)
    producent=db.Column(db.String)
    opis=db.Column(db.String)
    cena=db.Column(db.NUMERIC(8,2))

    @classmethod
    def get_produkty(cls) -> List['Produkt']:

        produkty = db.session.query(
            Produkt.id_produktu,
            Produkt.nazwa,
            Produkt.producent,
            Produkt.opis,
            Produkt.cena
        )
        return produkty

    def __repr__(self) -> str:
        return (
            'Produkt('
            f'nazwa={self.nazwa}, '
            f'nproducent={self.producent}, '
            f'opis={self.opis}, '
            f'cena={self.cena}, '
            ')>'
        )

class Wolontariusz(db.Model):
    __tablename__ = 'wolontariusz'

    id_osoby = db.Column(db.Integer, primary_key=True, autoincrement=True)
    imie=db.Column(db.String)
    nazwisko=db.Column(db.String)
    adres=db.Column(db.String)
    adres_email=db.Column(db.String)
    data_zatrudnienia=db.Column(db.Date)
    godziny_pracy=db.Column(db.String)
    haslo=db.Column(db.String)
    liczba_godzin_przepracowaanych_w_msc=db.Column(db.Integer)
    login=db.Column(db.String)
    numer_telefonu=db.Column(db.String)
    rodzaj_umowy=db.Column(db.String)
    stawka_godzinowa=db.Column(db.NUMERIC(5,2))
    pesel=db.Column(db.String)
    czy_pelnoletni=db.Column(db.Boolean)
    zgoda_opiekuna=db.Column(db.String)

    @classmethod
    def get_wolontariusze(cls) -> List['Wolontariusz']:

        wolontariusz = db.session.query(
            Wolontariusz.id_osoby,
            Wolontariusz.nazwisko,
            Wolontariusz.adres_email,
            Wolontariusz.numer_telefonu,
            Wolontariusz.godziny_pracy)
        return wolontariusz

    def __repr__(self) -> str:
        return (
            '<Wolontariusz('
            f'imie={self.imie}, '
            f'nazwisko={self.nazwisko}, '
            f'adres mailowy={self.adres_email}, '
            f'telefon={self.numer_telefonu}, '
            f'godziny pracy={self.godziny_pracy}'
            ')>'
        )

class Zamowienie(db.Model):
    __tablename__ = 'zamowienie'
    id_zamowienia = db.Column(db.Integer, primary_key=True, autoincrement=True)
    id_dostawcy = db.Column(db.Integer, db.ForeignKey('dostawca.id_osoby'))
    id_pracownika = db.Column(db.Integer, db.ForeignKey('pracownik_biura.id_osoby'))
    id_wolontariusza = db.Column(db.Integer, db.ForeignKey('wolontariusz.id_osoby'))
    data_zlozenia = db.Column(db.Date)
    data_dostawy = db.Column(db.Date)
    status = db.Column(db.String)
    kwota = db.Column(db.NUMERIC(10,2))
    komentarz=db.Column(db.String)

    pracownik = db.relationship(
        "Pracownik_biura"
       # backref=db.backref('pracownicy', lazy=False),
       # uselist=False,
    )
    dostawca = db.relationship(
        "Dostawca"
       # backref=db.backref('dostawcy', lazy=False),
       # cascade="all, delete, delete-orphan",
    )
    wolontariusz = db.relationship(
        "Wolontariusz"
       # backref=db.backref('wolontariusze', lazy=False),
       # uselist=False,
    )

    @classmethod
    def get_zamowienia(cls, id_dostawcy: int, id_pracownika: int,id_wolontariusza: int) -> List['Zamowienie']:

        zamowienia = db.session.query(
            Zamowienie,
        ).filter(
            Zamowienie.id_dostawcy == id_dostawcy,
            Zamowienie.id_pracownika == id_pracownika,
            Zamowienie.id_wolontariusza == id_wolontariusza,
        ).all()
        return zamowienia

    def __repr__(self) -> str:
        return (
            '<Zamowienie('
            f'id_zamowienia={self.id_zamowienia}, '
            f'venue_id={self.venue_id}, '
            f'score={self.score}, '
            f'review={self.review}, '
            f'inserted={self.inserted}'
            ')>'
        )

class Produkt_w_zamowieniu(db.Model):
    __tablename__ = 'produkt_w_zamowieniu'
    rowid = db.Column(db.String, primary_key=True)
    id_zamowienia = db.Column(db.Integer,db.ForeignKey('zamowienie.id_zamowienia'))
    id_produktu = db.Column(db.Integer, db.ForeignKey('produkt.id_produktu'))
    ilosc=db.Column(db.Integer)

    @classmethod
    def get_produkty_w_zamowieniu(cls) -> List['Produkt_w_zamowieniu']:

        produkty_w_zamowieniu = db.session.query(
            Produkt_w_zamowieniu.id_produktu,
            Produkt_w_zamowieniu.id_zamowienia,
            Produkt_w_zamowieniu.ilosc,
        )
        return produkty_w_zamowieniu

    def __repr__(self) -> str:
        return (
            'Produkt_w_zamowieniu('
            f'id_zamowienia={self.id_zamowienia}, '
            f'id_produktu={self.id_produktu}, '
            f'ilosc={self.ilosc}, '
            ')>'
        )
