from flask_sqlalchemy import SQLAlchemy
from flask import Flask, redirect, render_template, request, flash, session
from  models import *


app = Flask(__name__)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = (
    "postgresql://schronisko:schronisko@localhost:5433/db"
)
app.config['SQLALCHEMY_ECHO'] = True
app.config['SESSION_TYPE'] = 'memcached'
app.config['SECRET_KEY'] = 'super secret key'
db.init_app(app)


#engine = create_engine('postgresql://schronisko:schronisko@localhost:5433/db', echo=True)
user_type=""
user_login=""

@app.route('/')
def hello_world():
#'postgresql://postgres:password@localhost:5432/mytestdb'


   # result_set = db.execute("SELECT * FROM class_variables")
   # for r in result_set:
    #    print(r)
    host = request.host_url
    return render_template('main.html', pracownicy=Pracownik_biura.get_pracownicy(), host=host)
    #return 'Hello World!'

@app.route('/Profil')
def profil():
    return "profil"

@app.route('/create_order')
def create_order():
    prod_list = Produkt.get_produkty()
    dostawcy_list= Dostawca.get_dostawcy()
    return render_template('orders/create_order.html', produkty = prod_list, dostawcy = dostawcy_list)

@app.route('/order_check', methods=['POST'])
def check_order():
    id_dostawcy = request.form.get('dostawca')
    komentarz= request.form['komentarz']
    quantity_list=[]
    price_list = []
    produkty_ids = request.form.getlist('check')
    for prod_id in produkty_ids:
        name= prod_id+"quantity"
        quantity_list.append(request.form[name])
        price_list.append(Produkt.query.filter_by(id_produktu=prod_id).first().cena)

    return "razem"

@app.route('/orders')
def orders():
    return "lista zamowien"

@app.route('/Login')
def login():
    host = request.host_url
    return render_template('login.html',  host=host)

@app.route('/Register')
def register():
    return render_template('register.html',  host=request.host_url)

@app.route('/Register_check',methods=['POST'])
def register_check():
    typ_uzytkownika = request.form['user']
    if request.form['pass'] == request.form['pass2']:
        if typ_uzytkownika=="wolontariusz":
            imie = request.form['name']
            nazwisko = request.form['surname']
            adres_email = request.form['email']
            adres = request.form['adres']
            numer_telefonu = request.form['tel']
            haslo = request.form['pass']
            login = request.form['email']
            nowy_wolontariusz = Wolontariusz(imie=imie, nazwisko=nazwisko, adres_email=adres_email,
                                             adres=adres, numer_telefonu=numer_telefonu,haslo=haslo,
                                             login=login)
            db.session.add(nowy_wolontariusz)
            db.session.commit()
            return render_template('register_success.html')
        else:
            return render_template("register_progress.html", mail=request.form['email'])
    flash('Podane hasla nie byly identyczne, wprowadz dane ponownie')
    return  render_template('register.html')

@app.route('/Login_check',methods=['POST'])
def login_check():
    if request.form.get("login_b"):
        login = request.form.get('login')
        haslo = request.form.get('haslo')
        typ_uzytkownika = request.form.get('typ_uzytkownika')

        if typ_uzytkownika == "PB":
            uzytkownik = Pracownik_biura.query.filter_by(login=login).first()
            if not uzytkownik or uzytkownik.haslo != haslo:
                flash('Please check your login details and try again.')
                return render_template('Login.html')

        elif typ_uzytkownika == "W":
            uzytkownik = Wolontariusz.query.filter_by(login=login).first()
            if not uzytkownik or uzytkownik.haslo != haslo:
                flash('Please check your login details and try again.')
                return render_template('Login.html')

        elif typ_uzytkownika == "D":
            uzytkownik = Dostawca.query.filter_by(login=login).first()
            if not uzytkownik or uzytkownik.haslo != haslo:
                flash('Please check your login details and try again.')
                return render_template('Login.html')
        user_type = typ_uzytkownika
        user_login = login
        return render_template('login_success.html', imie=uzytkownik.imie)
    if request.form.get("register_b"):
        return render_template('register.html')


if __name__ == '__main__':
    app.run()
