from flask_sqlalchemy import SQLAlchemy
from flask import Flask, redirect, render_template, request, flash, session
from  models import *
from decimal import *
from datetime import datetime
from sqlalchemy import update

app = Flask(__name__)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = (
    "postgresql://schronisko:schronisko@localhost:5433/db"
)
app.config['SQLALCHEMY_ECHO'] = True
app.config['SESSION_TYPE'] = 'memcached'
app.config['SECRET_KEY'] = 'super secret key'
db.init_app(app)


#engine = create_engine('postgresql://schronisko:schronisko@localhost:5433/db', echo=True)
user_type=""
user_login=""

@app.route('/')
def hello_world():
#'postgresql://postgres:password@localhost:5432/mytestdb'


   # result_set = db.execute("SELECT * FROM class_variables")
   # for r in result_set:
    #    print(r)
    host = request.host_url
    return render_template('main.html', pracownicy=Pracownik_biura.get_pracownicy(), host=host)
    #return 'Hello World!'

@app.route('/Profil')
def profil():
    return "profil"

@app.route('/create_order')
def create_order():
    prod_list = Produkt.get_produkty()
    dostawcy_list= Dostawca.get_dostawcy()
    return render_template('orders/create_order.html', produkty = prod_list, dostawcy = dostawcy_list)

@app.route('/order_check', methods=['POST'])
def check_order():
    id_dostawcy = request.form.get('dostawca')
    komentarz= request.form['komentarz']
    quantity_list=[]
    produkty=[]
    price_list = []
    produkty_ids = request.form.getlist('check')
    razem=0
    for prod_id in produkty_ids:
        name= prod_id+"quantity"
        quantity_list.append(request.form[name])
        price_list.append(Produkt.query.filter_by(id_produktu=prod_id).first().cena)
        produkty.append(Produkt.query.filter_by(id_produktu=prod_id).first())
        razem=razem+Decimal(quantity_list[-1])*price_list[-1]
    dostawca = Dostawca.query.filter_by(id_osoby=id_dostawcy).first()

    return render_template('orders/order_confirm.html', dostawca=dostawca, komentarz=komentarz, ilosci=quantity_list,
                           produkty=produkty, razem=razem)

@app.route('/order_confirm', methods=['POST'])
def confirm_order():
    if user_login =="":
        return render_template("orders/not_logged_in.html")
    id_dostawcy = int(request.form.get('id_dostawcy'))
    komentarz = request.form.get('komentarz')
    suma = float(request.form.get('razem'))
    prod_ids=request.form.get('prod_id')
    prod_quant=request.form.get('prod_quant')
    id_pracownika, id_wolontariusza = None, None
    # user_type="PB"
    # user_login="apracowita"
    if user_type== "PB":
        id_pracownika=Pracownik_biura.query.filter_by(login=user_login).first().id_osoby
    elif user_type=="W":
        id_wolontariusza=Wolontariusz.query.filter_by(login=user_login).first().id_osoby
    data_zlozenia=datetime.date(datetime.now())
    nowe_zamowienie = Zamowienie(id_dostawcy = id_dostawcy, id_pracownika = id_pracownika, id_wolontariusza=id_wolontariusza,
                                 data_zlozenia=data_zlozenia, status="zatwierzdzone", kwota=suma, komentarz= komentarz)
    db.session.add(nowe_zamowienie)
    db.session.commit()
    id_zam=nowe_zamowienie.id_zamowienia
    for i in range(len(prod_ids)):
        nowy_prod_w_zam= Produkt_w_zamowieniu(id_produktu=int(prod_ids[i]), id_zamowienia=id_zam,ilosc=int(prod_quant[i]))
        db.session.add(nowy_prod_w_zam)
        db.session.commit()

    print(nowe_zamowienie.id_zamowienia)
    class_var = Class_variables.query.filter_by(id_class_variables=1).first()
    class_var.liczba_zlozonych_zamowien+=1
    db.session.commit()
    return render_template('orders/order_placed.html')

@app.route('/orders')
def orders():
    return "lista zamowien"

@app.route('/Login')
def login():
    host = request.host_url
    return render_template('login.html',  host=host)

@app.route('/Register')
def register():
    return render_template('register.html',  host=request.host_url)

@app.route('/Register_check',methods=['POST'])
def register_check():
    typ_uzytkownika = request.form['user']
    if request.form['pass'] == request.form['pass2']:
        if typ_uzytkownika=="wolontariusz":
            imie = request.form['name']
            nazwisko = request.form['surname']
            adres_email = request.form['email']
            adres = request.form['adres']
            numer_telefonu = request.form['tel']
            haslo = request.form['pass']
            login = request.form['email']
            nowy_wolontariusz = Wolontariusz(imie=imie, nazwisko=nazwisko, adres_email=adres_email,
                                             adres=adres, numer_telefonu=numer_telefonu,haslo=haslo,
                                             login=login)
            db.session.add(nowy_wolontariusz)
            db.session.commit()
            return render_template('register_success.html')
        else:
            return render_template("register_progress.html", mail=request.form['email'])
    flash('Podane hasla nie byly identyczne, wprowadz dane ponownie')
    return  render_template('register.html')

@app.route('/Login_check',methods=['POST'])
def login_check():
    if request.form.get("login_b"):
        login = request.form.get('login')
        haslo = request.form.get('haslo')
        typ_uzytkownika = request.form.get('typ_uzytkownika')

        if typ_uzytkownika == "PB":
            uzytkownik = Pracownik_biura.query.filter_by(login=login).first()
            if not uzytkownik or uzytkownik.haslo != haslo:
                flash('Please check your login details and try again.')
                return render_template('Login.html')

        elif typ_uzytkownika == "W":
            uzytkownik = Wolontariusz.query.filter_by(login=login).first()
            if not uzytkownik or uzytkownik.haslo != haslo:
                flash('Please check your login details and try again.')
                return render_template('Login.html')

        elif typ_uzytkownika == "D":
            uzytkownik = Dostawca.query.filter_by(login=login).first()
            if not uzytkownik or uzytkownik.haslo != haslo:
                flash('Please check your login details and try again.')
                return render_template('Login.html')
        user_type = typ_uzytkownika
        user_login = login
        return render_template('login_success.html', imie=uzytkownik.imie)
    if request.form.get("register_b"):
        return render_template('register.html')


if __name__ == '__main__':
    app.run()
